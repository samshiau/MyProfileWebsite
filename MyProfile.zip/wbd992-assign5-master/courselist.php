<?php

include_once ".env.php";
?>

<html lang="en-US">
  <head>
	  <title>Course List</title>
	  <link rel="stylesheet" type="text/css" href="css/cc.css">

   </head>
        <body>

                <h1 id="fp">
                        Course List
                <h1>
                <h2 id="fp">
                        <a href="index.php">Samuel Shiau's home page</a>
                </h2>
                <hr>




<?php


	$con=mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DATABASE);

	if(!$con){
		exit("<p class='error'> Connetion Error: " . mysqli_connect_error() . "</p>");
	}

	$stmt=mysqli_stmt_init($con);

	if (!$stmt){
    		exit("<p class='error'>Failed to initialize statement</p>");
	}

	if((is_array($_GET))&&(!empty($_GET)))
	{
	
		$queryD="DELETE FROM coursesnew WHERE id = ?";	

		if (!mysqli_stmt_prepare($stmt, $queryD)){
                        exit("<p class='error'>Failed to prepare statement</p>");
                }
	
		mysqli_stmt_bind_param($stmt, "i",$_GET['var']);

		if(!mysqli_stmt_execute($stmt)){
                        exit("<p class='error'>Failed to execute statement</p>");
                }

	
	
	}

	if ((is_array($_POST))&&(!empty($_POST))) 
	{

        	$query="INSERT INTO coursesnew (coursename, coursenumber, coursedescription, finalgrade, currentlyenrolled) VALUES (?,?,?,?,?)";

        	if (!mysqli_stmt_prepare($stmt, $query)){
                	exit("<p class='error'>Failed to prepare statement</p>");
        	}

        	if($_POST['ce']==TRUE){
                	$cev=1;
        	}
        	else{
                	$cev=0;
        	}

        	mysqli_stmt_bind_param($stmt, "ssssi",$_POST['cname'],$_POST['cnum'],$_POST['desc'],$_POST['fg'],$cev);

        	if(!mysqli_stmt_execute($stmt)){
                	exit("<p class='error'>Failed to execute statement</p>");
        				}
	}




	$query2="SELECT * from coursesnew";


	if (!mysqli_stmt_prepare($stmt, $query2)){
                exit("<p class='error'>Failed to prepare statement</p>");
	}

	if(!mysqli_stmt_execute($stmt)){
		exit("<p class='error'>Failed to execute statement</p>");
	
	}

	mysqli_stmt_bind_result($stmt,$id,$dcname,$dcnum,$dcdes,$dfg,$dce);

	echo "<table id='table'>";
	echo "<tr> <th> -Course name- </th> <th> -Course Number- </th> <th> -Description-  </th>  <th> -Final grade-  </th> <th> -Enrolled-  </th>  <th> -Delete- </th>   </tr>";

	while(mysqli_stmt_fetch($stmt) != NULL){
		if($dce==1){
			echo "<tr id='tab'  >  <td>$dcname</td> <td>$dcnum</td> <td>$dcdes</td> <td>$dfg</td> <td>$dce</td> <td> <a href='courselist.php?var=$id'> Delete </a>  </td> </tr>";
		
		}
		else{
			echo "<tr id='tabb2'>  <td>$dcname</td> <td>$dcnum</td> <td>$dcdes</td> <td>$dfg</td> <td>$dce</td> <td> <a href='courselist.php?var=$id'> Delete </a>  </td> </tr>";
			}
	}
	echo "</table>";



?>

	<br>
	<hr>
	<br>	
	<div id="formbox">
		<h3 id="fp"> Add your course: </h3>
		<form method="post" id="fp">
	
                	<label for="cname">Course name</label>
                	<input name="cname" type="text"></input>
                	<br>  <br>
                	<label for="cnum">Course number</label>
                	<input name="cnum" type="text"></input>
                	<br>  <br>
                	<label for="desc">Description</label>
                	<textarea name="desc" rows="3" cols="30"></textarea>
                	<br>  <br>
                	<label for="fg">Final Grade</label>
                	<input name="fg" type="text"></input>
                	<br>  <br>
                	<label for="ce">Currently enrolled?</label>
                	<input name="ce" type="checkbox"></input>
                	<br>  <br>
                	<input type="submit" value="Add course">
		</form>
	</div>

<?php

	mysqli_stmt_close($stmt);
	mysqli_close($con);


?>



        </body>
</html>


