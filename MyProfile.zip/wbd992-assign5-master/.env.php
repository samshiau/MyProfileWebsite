<?php

define('DB_SERVER', 'localhost');
define('DATABASE', 'courses');
define('DB_USERNAME', 'samshiau');
define('DB_PASSWORD', 'sampw');

