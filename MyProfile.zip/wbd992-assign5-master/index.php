<?php

if(isset($_POST['changemode'])){	

		if(!isset($_COOKIE['cm'])){
			setcookie("cm","grey",time()+300);
			echo'<body id="bodygrey">';
		}

		if(isset($_COOKIE['cm'])&&($_COOKIE['cm']=='grey')){
			setcookie("cm","white",time()+300);
			echo'<body id="bodywhite">';
		
		}

		if(isset($_COOKIE['cm'])&&($_COOKIE['cm']=='white')){
                        setcookie("cm","grey",time()+300);
                        echo'<body id="bodygrey">';

                }

		if($_COOKIE['cc']=='cc'){
			$case2="pc";
		}
		if($_COOKIE['cc']=='nc'){
			$case2="pnc";	
		}
}

?>

<html lang="en-US">
	<head>
		<title>Assignment 4</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>
	<div id="bp">	
		 
			<div id="titlep2">

				<div id="sbor">
                                	<img id="imgp" src=utsa.jpg>
                                </div>




				<div id="t">
					<br><br>
				<h1> Samuel Shiau </h1>
			
				<h3> <span id="occu">Software Engineer </span></h3>
				</div>		
			
				
					
			     	
      					
			
			</div>
		
		 <hr id="indexline">

		<table id="tablep">
			<tr>

				<?php
					if(isset($_POST['changecolor'])){
						if(!isset($_COOKIE['cc'])){
							setcookie("cc","nc",time()+300);
							echo'<td id="fcp2">';
							$case="nocolor";
						}
						if(isset($_COOKIE['cc'])&&($_COOKIE['cc']=='nc')){
							setcookie("cc","c",time()+300);
							echo'<td id="firstcolumnproperty">';
							$case="color";
						}
						if(isset($_COOKIE['cc'])&&($_COOKIE['cc']=='c')){
							setcookie("cc","nc",time()+300);
							echo'<td id="fcp2">';
							$case="nocolor";
						}


						if($_COOKIE['cm']=='grey'){
							echo'<body id="bodygrey">';
						}
						if($_COOKIE['cm']=='white'){
							echo'<body id="bodywhite">';
						}


					}
					else{
						if($case2=="pc"){
							echo'<td id="firstcolumnproperty">';
						}
						if($case2=="pnc"){
							echo'<td id="fcp2">';
						}

						else{
							echo'<td id="firstcolumnproperty">';
						}


					    }
				?>
	
					<span id="menuproperty"> Menu </span> 
					<hr>
					<ul>
                                        	<li> <a href="https://github.com/samshiau"> Github </a> </li>
                                        	<li> <a href="courselist.php">  Courses  </a>  </li>
                                		<li> <a href="https://www.utsa.edu/"> UTSA </a> </li>
                                	</ul>
				</td>

			


				<td id="cp"> 
					<span class="boldtx"> <h3> About me </h3> </span> 
					<img id="simgp" src=utsa.jpg>						
                                        		<p> My name is Samuel Shiau. I study Computer Science at UTSA. Software Engineering is my current concentration. I studied at a high school in Austin and moved to San Antonio five years ago. I was first not studying CS as my major, architecture was my first major. I decided to change it since I see more opportunities and fun in this major. This is my last semester at UTSA, I am looking forward to graduating. My name is Samuel Shiau. I study Computer Science at UTSA. Software Engineering is my current concentration. blah blah blah blah blah blah blah blah blah blah</p>  
						 
						
                                        		<p> My name is Samuel Shiau. I study Computer Science at UTSA. Software Engineering is my current concentration. I studied at a high school in Austin and moved to San Antonio five years ago. I was first not studying CS as my major, architecture was my first major. I decided to change it since I see more opportunities and fun in this major. This is my last semester at UTSA, I am looking forward to graduating. My name is Samuel Shiau. I study Computer Science at UTSA. Software Engineering is my current concentration. blah blah blah blah blah blah blah blah blah blah </p>
                    	
						
				</td>

				<?php
				if(isset($_POST['changecolor'])){
					if($case=="color"){
						echo'<td id="thirdcolumnproperty">';
					}
					if($case=="nocolor"){
						echo'<td id="tcp2">';
					}
				}
				else{
					if($case2=="pc"){
						echo'<td id="thirdcolumnproperty">';
					}
					if($case2=="pnc"){
						echo'<td id="tcp2">';
					}
					else{
						echo'<td id="thirdcolumnproperty">';
					}
				}
				?>
					<span class="boldtx">Enrolled courses</span>
					<hr>				
					<ol>
                                	
						<li>OS</li>
                                	
						<li>WT</li>
                                	
						<li>AP</li>
                                
					</ol>
					Theme Toggles
					<hr>

					<form method='post'>
					<input id="button" type="submit" value="Colors" name="changecolor">
					<br>
					<input id="button" type="submit" value="Dark Mode" name="changemode">
					</form>



				</td>

			</tr>
				

		</table>
		<div id="footerbox"> Copyright 2022 Samuel Shiau </div>
	</div>
	</body>
</html>

